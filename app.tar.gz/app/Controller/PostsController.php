<?php

/**
 * classe controller dos posts
 */
class PostsController extends AppController {
	public $name = "Posts";
	public $helpers = ['Html', 'Form'];

	public function index()
    {

		//enviandos dados para a view através da variavel posts
		$this->set('posts', $this->Post->find('all'));
		//so podemos usar $this->Post pois seguimoso padrão de nomeclatura cake
	}

	public function view($id = null)
    {
        $sanitized_id = is_numeric($id) ? $id : 0;
        $this->set('post', $this->Post->findById($sanitized_id));
	}
    public function create()
    {       //se $_POST
        
        if ($this->request->is('post')) {
            //guardando o resultado da inserção na variavel
                                                //dados da requisição
            $save_result = $this->Post->save($this->request->data);
        }

        if ($save_result) {
            
            $this->Flash->success('Postado com sucesso!');
            $this->redirect(['action' => 'index']);

        }

    }
    public function edit($id = null)
    {   
        $sanitized_id = is_numeric($id) ? $id : 0;
     
        if ( $this->request->is('get') ){
            $this->request->data = $this->Post->findById($sanitized_id);
            
        }   

        if ($this->request->is(['put', 'post'])) {

            $this->Post->save($this->request->data);
            $this->Flash->success("Registro editado com sucesso");
            $this->redirect(['controller' => 'Posts', 'action' => 'index' ]);
        
        }

    }

}
